import datetime
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField, IntegerField
from wtforms.validators import DataRequired, EqualTo
from flask import Flask, render_template, redirect
from data import db_session
from data.jobs import Jobs
from data.users import User


app = Flask(__name__)
app.config["SECRET_KEY"] = "da-da_secret_key"


class RegisterForm(FlaskForm):
    email = StringField("Login / email", validators=[DataRequired()])
    password = StringField("Password", validators=[DataRequired()])
    rep_password = StringField("Repeat password", validators=[DataRequired(), EqualTo('password',
                               message="Passwords must match")])
    surname = StringField("Surname", validators=[DataRequired()])
    name = StringField("Name", validators=[DataRequired()])
    age = IntegerField("Age", validators=[DataRequired()])
    position = StringField("Position", validators=[DataRequired()])
    speciality = StringField("Speciality", validators=[DataRequired()])
    address = StringField("Address", validators=[DataRequired()])
    submit = SubmitField("Submit")


def main():
    db_session.global_init("db/mars_explorer.db")
    db_sess = db_session.create_session()
    app.run()


@app.route("/")
@app.route("/index")
def base():
    title = "Base"
    return render_template("base.html", title=title)


@app.route("/works_log")
def works_log():
    print("guugugu")
    db_sess = db_session.create_session()
    works = db_sess.query(Jobs).all()
    print(works[0].team_leader)
    return render_template("works_log.html", works=works)


@app.route("/register", methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    db_sess = db_session.create_session()
    if form.validate_on_submit():
        new_user = User()
        new_user.surname = form.surname.data
        new_user.name = form.name.data
        new_user.age = form.age.data
        new_user.position = form.position.data
        new_user.speciality = form.speciality.data
        new_user.address = form.address.data
        new_user.email = form.email.data
        new_user.hashed_password = form.password.data
        db_sess.add(new_user)
        db_sess.commit()
        return redirect("/success")
    else:
        return render_template("login.html", form=form, title="Register")


@app.route("/success")
def success():
    return render_template("success.html", title="SUCCESS")


if __name__ == "__main__":
    main()
