import datetime

from flask import Flask, render_template
from data import db_session
from data.jobs import Jobs


app = Flask(__name__)
app.config["SECRET_KEY"] = "da-da_secret_key"


def main():
    db_session.global_init("db/mars_explorer.db")
    db_sess = db_session.create_session()
    app.run()


@app.route("/")
@app.route("/works_log")
def works_log():
    print("guugugu")
    db_sess = db_session.create_session()
    works = db_sess.query(Jobs).all()
    print(works[0].team_leader)
    return render_template("works_log.html", works=works)


if __name__ == "__main__":
    main()
